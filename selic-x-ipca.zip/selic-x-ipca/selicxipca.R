
# Packages ----------------------------------------------------------------


install.packages('GetBCBData')
#install.packages('ggdark')#dark mode themes
library(GetBCBData)
library(tidyverse)
#library(ggdark)

# Data --------------------------------------------------------------------


df <- GetBCBData::gbcbd_get_series(
  id = c('selic'=432, 'ipca'=13522),
  first.date = "2020-01-01",
  last.date = Sys.Date(),
  format.data = 'long'
)


# Graph -------------------------------------------------------------------


selicxipca <- ggplot(data = df) +
  geom_line(aes(x = ref.date, y = value, colour = series.name), size = 1, lineend = 'round', linejoin = 'round')+
  geom_segment(x = df[443,1], y = 2, xend = df[852,1], yend = 2, colour = 'black', arrow = arrow(angle = 15, length = unit(.25, "centimeters"), ends = "both", type = "open"))+
  scale_y_continuous(n.breaks = 20)+
  annotate("text", x = df[640,1], y = 2.25, label= "Defasagem temporal da política monetária (409 dias)", colour = 'black', size = 4)+
  labs(x = "Tempo",
       y = "Taxa",
       title = "SELIC x IPCA",
       subtitle = "2020 - 2023",
       colour = '')+
  theme_light()
  #dark_theme_light() #For dark mode (may cause problems)
print(selicxipca)

